<?php
$pagina_atual = basename($_SERVER['PHP_SELF']);
?>

<nav class="navbar bg-zinc-700">
    <div class="container-fluid d-flex justify-content-between align-items-center">
        <a class="h3 rounded" href="efetuado.php" style="text-decoration: none; font-weight: 999; color: black; background-color: white;">Web_app</a>
        
        <?php if ($pagina_atual == 'marcar.php'): ?>
            <button type="button" class="btn btn-dark btn-sm" onclick="window.location.href='efetuado.php'">Voltar</button>
        <?php endif; ?>

        <?php if ($pagina_atual == 'suas_reservas.php'): ?>
            <button type="button" class="btn btn-dark btn-sm" onclick="window.location.href='marcar.php'">Voltar</button>
        <?php endif; ?>
        
        <button type="button" class="btn btn-primary btn-sm"
            onclick="document.documentElement.setAttribute(
                'data-bs-theme',
                document.documentElement.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark'
            )">
            Alternar Tema
        </button>
    </div>
</nav>