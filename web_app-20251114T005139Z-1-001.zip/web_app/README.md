**Autor: Pedro Miguel - Turma: 3ª DS - Instituição de Ensino: Escola Estadual Joaquim de Moura Candelária**<br>
O Projeto Web App foi desenvolvido para ter as seguintes funções: Autenticar usuarios(Cadastrar e Entrar), Alterar a senha quando estiver logado.<br>
Tecnologias Aplicadas: *Bootstrap 5*, *CSS 3*, *HTML 5*, *JS*, *PHP*.
